# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Top-level entry-point script for model training (also supports loading for inference)
"""
# Local Dependencies:
from sm_job_utils import configure_sm_job


def run_training():
    """Configure logging & env vars, import local modules and run the training job"""
    configure_sm_job()

    from sagemaker_whisper.training.train import main

    return main()


if __name__ == "__main__":
    # If the file is running as a script, we're in training mode and should run the actual training
    # routine (with a little logging setup before any imports, to make sure output shows up ok):
    run_training()
else:
    # If the file is imported as a module, we're in inference mode and should pass through the
    # override functions defined in the inference module. This is to support directly deploying the
    # model via SageMaker SDK's Estimator.deploy(), which will carry over the environment variable
    # SAGEMAKER_PROGRAM=train.py from training - causing the server to try and load handlers from
    # here rather than inference.py.
    from sagemaker_whisper.inference import *


def _mp_fn(index):
    """For torch_xla / SageMaker Training Compiler

    (See entry_train_smtc.py in this folder for configuration tips) TODO: Doesn't exist yet...
    """
    return run_training()
