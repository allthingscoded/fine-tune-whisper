# Python Built-Ins:
from numbers import Real
from typing import Callable, Dict

# External Dependencies:
import evaluate
from transformers import WhisperTokenizer
from transformers.models.whisper.english_normalizer import BasicTextNormalizer
from transformers.trainer_utils import EvalPrediction


metric = evaluate.load("wer")
normalizer = BasicTextNormalizer()


def compute_eval_metrics(pred_str: list[str], label_str: list[str]) -> Dict[str, Real]:
    # compute orthographic WER
    wer_ortho = 100 * metric.compute(predictions=pred_str, references=label_str)

    # compute normalized WER
    pred_str_norm = [normalizer(pred) for pred in pred_str]
    label_str_norm = [normalizer(label) for label in label_str]

    # filtering step to only evaluate the samples that correspond to non-zero ground truth references:
    pred_str_norm = [
        pred_str_norm[i]
        for i in range(len(pred_str_norm))
        if len(label_str_norm[i]) > 0
    ]
    label_str_norm = [
        label_str_norm[i]
        for i in range(len(label_str_norm))
        if len(label_str_norm[i]) > 0
    ]
    wer = 100 * metric.compute(predictions=pred_str_norm, references=label_str_norm)

    return {"wer_ortho": wer_ortho, "wer": wer}


def get_metric_computer(tokenizer: WhisperTokenizer) -> Callable[[EvalPrediction], Dict[str, Real]]:
    """Build a HF Trainer compute_metrics callback for ASR Word Error Rate (WER)"""
    metric = evaluate.load("wer")
    normalizer = BasicTextNormalizer()

    def compute_metrics(pred):
        pred_ids = pred.predictions
        label_ids = pred.label_ids

        # replace -100 with the pad_token_id
        label_ids[label_ids == -100] = tokenizer.pad_token_id

        # we do not want to group tokens when computing the metrics
        pred_str = tokenizer.batch_decode(pred_ids, skip_special_tokens=True)
        label_str = tokenizer.batch_decode(label_ids, skip_special_tokens=True)

        # compute orthographic WER
        wer_ortho = 100 * metric.compute(predictions=pred_str, references=label_str)

        # compute normalized WER
        pred_str_norm = [normalizer(pred) for pred in pred_str]
        label_str_norm = [normalizer(label) for label in label_str]

        # filtering step to only evaluate the samples that correspond to non-zero ground truth references:
        pred_str_norm = [
            pred_str_norm[i]
            for i in range(len(pred_str_norm))
            if len(label_str_norm[i]) > 0
        ]
        label_str_norm = [
            label_str_norm[i]
            for i in range(len(label_str_norm))
            if len(label_str_norm[i]) > 0
        ]
        wer = 100 * metric.compute(predictions=pred_str_norm, references=label_str_norm)

        return {"wer_ortho": wer_ortho, "wer": wer}

    return compute_metrics
