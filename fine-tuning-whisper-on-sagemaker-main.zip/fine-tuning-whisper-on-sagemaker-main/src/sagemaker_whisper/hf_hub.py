# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Utilities for working with Hugging Face Hub from SageMaker jobs"""
# Python Built-Ins:
from logging import getLogger

# External Dependencies:
import boto3
from huggingface_hub import login


logger = getLogger("hf_hub")


def huggingface_hub_login(secret_id: str) -> None:
    """Retrieve a token from AWS Secrets Manager and log in to Hugging Face Hub

    Parameters
    ----------
    secret_id :
        Name or ARN of an AWS Secrets Manager string secret, which should store your Hugging Face
        access token.
    """
    secman = boto3.client("secretsmanager")
    logger.info("Logging in to Hugging Face Hub...")
    login(token=secman.get_secret_value(SecretId=secret_id)["SecretString"])
    logger.info("Logged in")
