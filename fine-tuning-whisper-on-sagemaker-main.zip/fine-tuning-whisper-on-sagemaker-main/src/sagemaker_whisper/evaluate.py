import argparse
import json
import logging
import tarfile

from pathlib import Path
from typing import Optional 

import torch
from datasets import load_dataset
from transformers import pipeline
from transformers.pipelines.pt_utils import KeyDataset

from . metrics import compute_eval_metrics


logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    """Parse SageMaker Processing CLI arguments for fine-tuned Whisper evaluation"""
    parser = argparse.ArgumentParser(
        description="Evaluate fine-tuned Whisper model."
    )
    parser.add_argument(
        "--language_name",
        type=str,
        help="ISO language name, e.g. indonesian, thai",
        required=True,
    )
    args = parser.parse_args()
    return args


def main(args: Optional[argparse.Namespace] = None) -> None:
    """ Evaluate a trained model.
        This script is called from SageMaker Pipeline processing step.
        
    Parameters
    ----------
      - `language_name` to indicate the language of generated output.

    Beside `args` parameters as input, the script expects that:
      - model_path is located at `/opt/ml/processing/model/model.tar.gz`
      - dataset_path is located at `/opt/ml/processing/output/`. The dataset follows Hugging Face dataset structure, and the evaluation takes the test set of the dataset.
    """
    
    args = parse_args()
    logger.info("Loaded arguments:\n%s", args)

    model_path = "/opt/ml/processing/model/model.tar.gz"
    dataset_path = "/opt/ml/processing/output/"
    
    with tarfile.open(model_path) as tar:
        tar.extractall(path=".")
    
    # Load model 
    # We load the model in half-precision (float16) if running on a GPU to speed up inference. 
    # Reference: https://huggingface.co/learn/audio-course/chapter5/evaluation#putting-it-all-together
    if torch.cuda.is_available():
        device = "cuda:0"
        torch_dtype = torch.float16
    else:
        device = "cpu"
        torch_dtype = torch.float32

    pipe = pipeline(
        "automatic-speech-recognition",
        model=".",  # we extracted tarfile in the current path
        torch_dtype=torch_dtype,
        device=device,
    )
    
    # Load test dataset
    testset = load_dataset(dataset_path, split="test")
    
    # Generate prediction
    all_predictions = []
    for prediction in pipe(
        KeyDataset(testset, "audio"),
        max_new_tokens=128,
        generate_kwargs={
            "task": "transcribe",
            "language": args.language_name,
        },
        batch_size=32,
    ):
        all_predictions.append(prediction["text"])    
    
    # Evaluate prediction
    results = compute_eval_metrics(all_predictions, testset["sentence"])
    
    # Store prediction in report
    report_dict = {
        "metrics": {
            "wer_ortho": {"value": results["wer_ortho"]},
            "wer": {"value": results["wer"]}
        },
    }
    
    output_dir = "/opt/ml/processing/evaluation"
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    logger.info(f"Writing out evaluation report with wer_ortho: {results['wer_ortho']} and wer: {results['wer']}")
    evaluation_path = f"{output_dir}/evaluation.json"
    with open(evaluation_path, "w") as f:
        f.write(json.dumps(report_dict))    

    # For analysis purpose, we generate pred_label_pair to file
    pred_label_pairs = []
    for i, pred in enumerate(all_predictions):
        pred_label_pairs.append((pred, testset["sentence"][i]))
    #logger.info(pred_label_pairs)
    pred_output_path = f"{output_dir}/pred_label_pairs.json"
    with open(pred_output_path, "w") as f:
        f.write(json.dumps(pred_label_pairs))
    
        
if __name__ == "__main__":
    main()