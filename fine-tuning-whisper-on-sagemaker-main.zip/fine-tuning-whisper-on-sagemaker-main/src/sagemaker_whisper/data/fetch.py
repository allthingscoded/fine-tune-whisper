"""SageMaker Processing Script to fetch the Mozilla Common Voice dataset from Hugging Face Hub

You don't want to do this locally in SageMaker Studio, because the filesystem-based (rather than
block-store-based) local storage will make the process take hours. On a SageMaker Processing Job
like this, it can be ~15mins.
"""
# Python Built-Ins:
import argparse
from logging import getLogger
import os
from typing import Optional

# External Dependencies:
import datasets

# Local Dependencies:
from ..config import get_n_cpus
from ..hf_hub import huggingface_hub_login


logger = getLogger(__name__)


def parse_args() -> argparse.Namespace:
    """Parse SageMaker Processing CLI arguments for dataset fetch job"""
    parser = argparse.ArgumentParser(
        description="Fetch a dataset from Hugging Face Hub (by default: Mozilla Common Voice)"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="/opt/ml/processing/output",
        help="Folder where datasets should be saved",
    )
    parser.add_argument(
        "--cache-dir",
        type=str,
        default="/tmp/hf/checkpoints",
        help="Cache folder to use for fetching/unpacking Hugging Face datasets",
    )
    parser.add_argument(
        "--dataset-name",
        type=str,
        default="mozilla-foundation/common_voice_13_0",
        help="Name of the source dataset on Hugging Face Hub",
    )
    parser.add_argument(
        "--hf_secret_id",
        type=str,
        default="hf-hub-token",
        help="Name or ARN of the AWS Secrets Manager Secret storing your Hugging Face Hub Token",
    )
    parser.add_argument(
        "--language_code",
        type=str,
        help="(ISO 639-1 two-letter) code for the language to be fetched: E.g. 'th' for Thai",
        required=True,
    )
    parser.add_argument(
        "--num_workers",
        type=int,
        default=get_n_cpus() - 1,
        help="Number of worker processes to use (defaults to num CPUs - 1)",
    )
    parser.add_argument(
        "--norm_sample_rate",
        type=int,
        default=None,
        help=(
            "Optionally normalize the sample rate of all records' \"audio\" fields. In Hz i.e. "
            "16000 = 16kHz"
        ),
    )
    parser.add_argument(
        "--save_num_shards",
        type=int,
        default=None,
        help=(
            "Optionally override the number of shards (files) each dataset is saved to, for "
            "optimizing downstream processing"
        ),
    )
    args = parser.parse_args()
    os.makedirs(args.cache_dir, exist_ok=True)
    return args


def main(args: Optional[argparse.Namespace] = None) -> datasets.DatasetDict:
    """Fetch a dataset from Hugging Face Hub and save it to local folder.

    Parameters
    ----------
    args :
        Parsed CLI configuration for the dataset fetch job. If not provided, `parse_args()` will be
        called automatically to fetch the current running program's configuration.
    """
    if args is None:
        args = parse_args()
        logger.info("Loaded arguments:\n%s", args)

    huggingface_hub_login(args.hf_secret_id)

    logger.info("Fetching datasets...")
    common_voice = datasets.load_dataset(
        args.dataset_name,
        args.language_code,
        cache_dir=args.cache_dir,
        use_auth_token=True,
    )
    # Alternatively to customize the splits:
    # common_voice = datasets.DatasetDict()
    # common_voice["train"] = datasets.load_dataset(
    #     args.dataset_name,
    #     args.language_code,
    #     split="train+validation",
    #     cache_dir=args.cache_dir,
    #     use_auth_token=True,
    # )
    # common_voice["test"] = datasets.load_dataset(
    #     args.dataset_name,
    #     args.language_code,
    #     split="test",
    #     cache_dir=args.cache_dir,
    #     use_auth_token=True,
    # )
    if args.norm_sample_rate:
        logger.info(f"Will normalize audio sample rate to {args.norm_sample_rate} Hz")
        # TODO: Don't think this is actually doing the work up-front?
        common_voice = common_voice.cast_column(
            "audio", datasets.Audio(sampling_rate=args.norm_sample_rate)
        )
    print(common_voice)
    logger.info("Saving datasets...")
    # common_voice = common_voice.remove_columns(["path"])  # TODO: Parameterize / delete?
    if args.save_num_shards:
        num_shards = {split: args.save_num_shards for split in common_voice.keys()}
    else:
        num_shards = None
    common_voice.save_to_disk(args.output, num_proc=args.num_workers, num_shards=num_shards)
    logger.info("Done")
    return common_voice


if __name__ == "__main__":
    main()
