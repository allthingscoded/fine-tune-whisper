"""Common configuration utilities shared between training/pre-processing/etc"""
# Python Built-Ins:
import os


def get_n_cpus() -> int:
    """Get the number of CPUs available to the current process
    
    This can be overridden via the SM_NUM_CPUS environment variable
    """
    # Note os.sched_getaffinity() returns cores available to the current process, whereas
    # os.cpu_count would return the total number of cores on the system
    return int(os.environ.get("SM_NUM_CPUS", len(os.sched_getaffinity(0))))


def get_n_gpus() -> int:
    """Get the number of GPU accelerators available to the current process
    
    This can be overridden via the SM_NUM_GPUS environment variable
    """
    try:
        from torch.cuda import device_count
        default_n_gpus = device_count()
    except:
        default_n_gpus = 0
    return int(os.environ.get("SM_NUM_GPUS", default_n_gpus))
