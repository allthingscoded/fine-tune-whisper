# Python Built-Ins:
from logging import getLogger
import os
import shutil
from functools import partial
from typing import Optional, Tuple

# External Dependencies:
import datasets
from transformers import (
    AutoConfig,
    EarlyStoppingCallback,
    PretrainedConfig,
    PreTrainedModel,
    PreTrainedTokenizerFast,
    ProcessorMixin,
    Seq2SeqTrainer,
    set_seed,
    WhisperFeatureExtractor,
    WhisperForConditionalGeneration,
    WhisperProcessor,
    WhisperTokenizer,
)
from transformers.trainer_utils import get_last_checkpoint

# Local Dependencies:
from . import config
from ..data.collators import DataCollatorSpeechSeq2SeqWithPadding
from ..metrics import get_metric_computer


logger = getLogger(__name__)


def copy_inf_code_to_sagemaker_output(model_dir: str):
    """Enable directly deploying the trained model via SageMaker SDK's Estimator.deploy()

    To enable directly deploying this model via SageMaker SDK's Estimator.deploy() (rather than
    needing to create a PyTorchModel with entry_point / source_dir args), we need to save any
    inference handler function code to model_dir/code. Here we compromise efficiency to the
    benefit of usage simplicity, by just copying the contents of this training code folder to the
    model/code folder for inference:

    Parameters
    ----------
    model_dir :
        The output folder where the SageMaker model is being saved
    """
    code_path = os.path.join(model_dir, "code")
    if not os.path.abspath(".").startswith("/opt/ml/"):
        logger.warning(
            "Skipping output code copy step: Seems not to be running inside SageMaker job"
        )
        # If you try to recursively copy '.' in, for example, a SMStudio environment where '.' is
        # the notebooks/ folder (not notebooks/src) and notebooks/data is populated - you could be
        # waiting a very... long... time... Just create an empty folder to demonstrate:
        os.makedirs(code_path, exist_ok=True)
    else:
        logger.info(f"Copying code to {code_path} for inference")
        for currpath, _, files in os.walk("."):
            for file in files:
                # Skip any filenames starting with dot:
                if file.startswith("."):
                    continue
                filepath = os.path.join(currpath, file)
                # Skip any pycache or dot folders:
                if ((os.path.sep + ".") in filepath) or ("__pycache__" in filepath):
                    continue
                relpath = filepath[len(".") :]
                if relpath.startswith(os.path.sep):
                    relpath = relpath[1:]
                outpath = os.path.join(code_path, relpath)
                logger.info(f"Copying {filepath} to {outpath}")
                os.makedirs(outpath.rpartition(os.path.sep)[0], exist_ok=True)
                shutil.copy2(filepath, outpath)


def prepare_data_batch(
    batch: dict,
    feature_extractor: WhisperFeatureExtractor,
    tokenizer: WhisperTokenizer,
):
    """Pre-process and tokenize a single (batch of) data ready for model training"""
    # TODO: Why does this not work with batched data?
    # load and resample audio data from 48 to 16kHz
    audio = batch["audio"]

    # compute log-Mel input features from input audio array
    if isinstance(audio, list):
        sampling_rate = audio[0]["sampling_rate"]  # Sampling rates should all match so take first
        batch["input_features"] = feature_extractor(
            [a["array"] for a in audio], sampling_rate=sampling_rate
        ).input_features
        # batch["input_features"] = [f[0] for f in features.input_features]
    else:
        batch["input_features"] = feature_extractor(
            audio["array"], sampling_rate=audio["sampling_rate"]
        ).input_features[0]

    # encode target text to label ids
    batch["labels"] = tokenizer(batch["sentence"]).input_ids
    return batch


def prepare_dataset(
    dataset: datasets.DatasetDict,
    feature_extractor: WhisperFeatureExtractor,
    tokenizer: WhisperTokenizer,
    sampling_rate: int = 16000,
    num_workers: Optional[int] = None,
    batch_size: int = 16,
) -> datasets.DatasetDict:
    """Whatever dataset pre-processing that happens in the training job"""
    result = dataset.cast_column("audio", datasets.Audio(sampling_rate=sampling_rate))
    logger.info("Normalized sampling rate")
    return result.map(
        prepare_data_batch,
        batched=True,
        batch_size=batch_size,
        remove_columns=result.column_names["train"],  # Strip original fields - only take fn returns
        fn_kwargs={
            "feature_extractor": feature_extractor,
            "tokenizer": tokenizer,
        },
        num_proc=num_workers,
        desc="Tokenizing and extracting features",
        # cache_file_name=map_cache_file_name,
    )


def get_model(
    model_args: config.ModelArguments, data_args: config.DataTrainingArguments
) -> Tuple[PretrainedConfig, PreTrainedModel, PreTrainedTokenizerFast, ProcessorMixin]:
    """Load the model and its associated config/pre-processors ready for training"""
    config = AutoConfig.from_pretrained(
        model_args.config_name if model_args.config_name else model_args.model_name_or_path,
        finetuning_task=data_args.task_name,
        cache_dir=model_args.cache_dir,
        revision=model_args.model_revision,
        use_auth_token=True if model_args.use_auth_token else None,
    )

    # Load the tokenizer and feature extractor
    tokenizer_name_or_path = (
        model_args.tokenizer_name if model_args.tokenizer_name else model_args.model_name_or_path
    )
    feature_extractor = WhisperFeatureExtractor.from_pretrained(model_args.model_name_or_path)
    tokenizer = WhisperTokenizer.from_pretrained(
        model_args.model_name_or_path, language=model_args.language, task=data_args.task_name,
    )
    processor = WhisperProcessor(feature_extractor=feature_extractor, tokenizer=tokenizer)

    model = WhisperForConditionalGeneration.from_pretrained(model_args.model_name_or_path)
    model.config.forced_decoder_ids = None
    model.config.suppress_tokens = []

    # disable cache during training since it's incompatible with gradient checkpointing
    model.config.use_cache = False

    # set language and task for generation and re-enable cache
    model.generate = partial(
        model.generate, language=model_args.language, task="transcribe", use_cache=True
    )
    return config, model, tokenizer, processor


def main() -> Seq2SeqTrainer:
    """CLI script entry point to parse arguments and run training"""
    model_args, data_args, training_args = config.parse_args()
    logger.info("Loaded arguments:\n%s\n%s\n%s", model_args, data_args, training_args)

    logger.info("Starting!")
    if training_args.seed:
        set_seed(training_args.seed)
    else:
        logger.info("Random seed not set - results will be non-deterministic")

    training_args._setup_devices  # Force distributed setup if applicable and not already done
    logger.info("Started with local_rank %s", training_args.local_rank)
    # Don't strictly need this around the model setup too, but keeps logs more understandable:
    # Using the HF decorator rather than torch.distributed.barrier() to try and keep a bit more
    # environment-agnostic:
    with training_args.main_process_first(desc="Waiting for main process to load model and data"):
        logger.info("Creating config and model")
        _, model, tokenizer, processor = get_model(model_args, data_args)

        # Detecting last checkpoint.
        last_checkpoint = None
        if os.path.isdir(training_args.output_dir) and training_args.do_train:
            last_checkpoint = get_last_checkpoint(training_args.output_dir)
            if last_checkpoint is None and len(os.listdir(training_args.output_dir)) > 0:
                logger.warning("No previous checkpoint found: training from scratch")
            elif last_checkpoint is not None and training_args.resume_from_checkpoint is None:
                logger.info(
                    f"Checkpoint detected, resuming training at {last_checkpoint}. To avoid this "
                    "behavior, create the training job with an empty `checkpoint_s3_uri` or none."
                )

        logger.info(f"Loading datasets with {data_args.dataproc_num_workers} workers")
        # Load the training and validation datasets
        # TODO: n_workers, cache_dir
        dataset = datasets.load_dataset(data_args.dataset)
        dataset = prepare_dataset(
            dataset,
            feature_extractor=processor.feature_extractor,
            tokenizer=tokenizer,
            sampling_rate=model_args.audio_sample_rate,
            num_workers=data_args.dataproc_num_workers,
            batch_size=data_args.dataproc_batch_size,
        )

    data_collator = DataCollatorSpeechSeq2SeqWithPadding(processor=processor)
    logger.info("Setting up trainer")
    trainer = Seq2SeqTrainer(
        args=training_args,
        model=model,
        train_dataset=dataset["train"],
        eval_dataset=dataset["validation"],
        callbacks=[
            EarlyStoppingCallback(
                early_stopping_patience=training_args.early_stopping_patience,
                early_stopping_threshold=training_args.early_stopping_threshold,
            )
        ]
        if (
            training_args.early_stopping_patience is not None
            or training_args.early_stopping_threshold is not None
        )
        else [],
        compute_metrics=get_metric_computer(tokenizer),
        data_collator=data_collator,
        tokenizer=processor.feature_extractor,
    )
    checkpoint = None
    if training_args.resume_from_checkpoint is not None:
        checkpoint = training_args.resume_from_checkpoint
    elif last_checkpoint is not None:
        checkpoint = last_checkpoint
    train_result = trainer.train(resume_from_checkpoint=checkpoint)
    metrics = train_result.metrics
    trainer.log_metrics("train", metrics)

    logger.info(f"Saving model to {training_args.model_dir}")
    trainer.save_metrics("train", metrics)
    trainer.save_state()
    trainer.save_model(training_args.model_dir)
    processor.save_pretrained(os.path.join(training_args.model_dir))
    copy_inf_code_to_sagemaker_output(training_args.model_dir)  # Enable one-click estimator.deploy

    logger.info("Training finished")
    return trainer


if __name__ == "__main__":
    main()
