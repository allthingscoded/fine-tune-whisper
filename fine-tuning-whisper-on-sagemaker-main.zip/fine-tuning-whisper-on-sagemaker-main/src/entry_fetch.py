# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Top-level entry-point script for source dataset fetching (Mozilla Common Voice)
"""
# Local Dependencies:
from sm_job_utils import configure_sm_job


def run_fetch():
    """Configure logging & env vars, import local modules and run the job"""
    configure_sm_job()

    from sagemaker_whisper.data.fetch import main

    return main()


if __name__ == "__main__":
    run_fetch()
