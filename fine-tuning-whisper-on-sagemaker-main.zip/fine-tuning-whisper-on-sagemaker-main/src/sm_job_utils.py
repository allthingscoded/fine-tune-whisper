# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Common utilities needed by SageMaker entry_* scripts 
"""
# Python Built-Ins:
import logging
import os
import sys


def configure_sm_job() -> None:
    """Configure Python logger and AWS_DEFAULT_REGION env vars for SageMaker jobs
    
    Call this method *before* importing from the sagemaker_whisper package, to set up log outputs.
    Infers default level from the LOG_LEVEL environment variable, defaulting to INFO.
    
    SageMaker Processing Jobs set the AWS_REGION environment variable but *not* AWS_DEFAULT_REGION,
    which can cause issues with some SDKS - so this function fixes that too.
    """
    # Set up Python logging to actually output to CloudWatch:
    consolehandler = logging.StreamHandler(sys.stdout)
    consolehandler.setFormatter(
        logging.Formatter("%(asctime)s [%(name)s] %(levelname)s %(message)s")
    )
    logging.basicConfig(handlers=[consolehandler], level=os.environ.get("LOG_LEVEL", logging.INFO))

    # Set up missing default region env var for SM Processing:
    os.environ["AWS_DEFAULT_REGION"] = os.environ["AWS_REGION"]
