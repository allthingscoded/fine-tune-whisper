# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Load custom inference handlers for model deployment
"""
# TODO: Should we be running the logger/env var method in here or not?
from sagemaker_whisper.inference import *
